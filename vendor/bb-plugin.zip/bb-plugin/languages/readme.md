# WARNING! Do not place your translation files here.

Any translation files placed here will be deleted when you update the plugin.

## Translating the plugin

If you would like to help out translating the plugin, please contact us at [http://translate.wpbeaverbuilder.com/contact-the-administrator/].