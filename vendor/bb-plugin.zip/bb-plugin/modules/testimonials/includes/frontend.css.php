.fl-node-<?php echo $id; ?> .fl-testimonials-wrap.compact h3 {
	font-size: <?php echo $settings->heading_size; ?>px;
}
.fl-node-<?php echo $id; ?> .fl-testimonials-wrap .bx-pager.bx-default-pager a,
.fl-node-<?php echo $id; ?> .fl-testimonials-wrap .bx-pager.bx-default-pager a.active {
	background: #<?php echo $settings->dot_color; ?>;
	opacity: 1;
}
.fl-node-<?php echo $id; ?> .fl-testimonials-wrap .bx-pager.bx-default-pager a {
	opacity: 0.2;
}
.fl-node-<?php echo $id; ?> .fl-testimonials-wrap .fa:hover,
.fl-node-<?php echo $id; ?> .fl-testimonials-wrap .fa {
	color: #<?php echo $settings->arrow_color; ?>;
}
.fl-node-<?php echo $id; ?> .fl-testimonials-wrap.fl-testimonials-no-heading {
	padding-top: 25px;
}
