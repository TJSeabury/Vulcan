<?php // Display separator ?>
<div class="fl-separator"></div>
