<div class="fl-html">
	<?php echo $settings->html; ?>
</div>
