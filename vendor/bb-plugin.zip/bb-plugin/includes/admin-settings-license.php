<div id="fl-license-form" class="fl-settings-form">
	<?php do_action( 'fl_themes_license_form' ); ?>
</div>
