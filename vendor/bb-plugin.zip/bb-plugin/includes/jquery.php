<script type="text/javascript">

if(typeof jQuery == 'undefined' || typeof jQuery.fn.on == 'undefined') {
	document.write('<script src="<?php echo includes_url( 'js/jquery/jquery.js' ); ?>"><\/script>');
	document.write('<script src="<?php echo includes_url( 'js/jquery/jquery-migrate.min.js' ); ?>"><\/script>');
}

</script>
